<?php
/**
 * Plugin Name:       BG Report for WooCommerce
 * Plugin URI:        https://
 * Description:       Create Report with XML file for the Bulgarien Law. Export XML file by months.
 * Version:           1.0.0
 * Tags:              Report for the Bulgarien Law
 * Author:            wphelpme
 * Author URI:        https:/#
 * Text Domain:       bg-report-for-woocommerce
 * License:           GPL-2.0+
 * License URI:       
 *
 */
// Do not allow direct access to the file.
if( ! defined( 'ABSPATH' ) ) {
    exit;
}
/**
 * All admin scripts and styles.
 */
	function report_admin_scripts() {
    // Load the datepicker script (pre-registered in WordPress).
    wp_enqueue_script( 'jquery-ui-datepicker' );
    wp_enqueue_script( 'bg_report-datepicker', plugin_dir_url(__FILE__) . '/js/datepicker.js');
    wp_enqueue_style( 'bg_report-jquery-ui', '//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css' );		
	wp_enqueue_style( 'bg_report-admin-css', plugin_dir_url(__FILE__) . '/css/note.css');
	}
	add_action('admin_enqueue_scripts', 'report_admin_scripts');
/**
 * User Section
 */
	add_action('admin_menu', 'report_menu');
	function report_menu() {
		add_menu_page('BG Report', 'BG Report', 'administrator', 'bg_report', 'report_settings_page', 'dashicons-calendar-alt');
	}
	add_action( 'admin_init', 'bg_report_plugin_settings' );
	function bg_report_plugin_settings() {
	    register_setting( 'bg_report', 'bg_eik' );
	    register_setting( 'bg_report', 'bg_shop_number' );
	    register_setting( 'bg_report', 'domain_name' );
	    register_setting( 'bg_report', 'bg_creation_date' );
	    register_setting( 'bg_report', 'bg_month' );
	    register_setting( 'bg_report', 'bg_year' );
	    register_setting( 'bg_report', 'e_shop_type' );
	    register_setting( 'bg_report', 'vpos_name' );
	}
	function report_settings_page() {
	?>
	<div id="report-plugin">		
	    <h1><?php esc_html_e('Report', 'bg-report-for-woocommerce'); ?></h1>
	    <br />
		<form autocomplete="off" action="options.php" method="post" role="form" name="custom-report">
			<?php settings_fields( 'bg_report' ); ?>
			<?php do_settings_sections( 'bg_report' ); ?>
		<table border="1">
			<tr>
				<td><span><?php esc_html_e('Add EIK: ', 'bg-report-for-woocommerce'); ?></span></td>
				<td><input autocomplete="off" placeholder="<?php esc_html_e('bg_eik', 'bg-report-for-woocommerce'); ?>" name="bg_eik" value="<?php echo esc_html(get_option('bg_eik')); ?>" /></td>
			</tr>
			<tr>
				<td><span><?php esc_html_e('E-Shop Number: ', 'bg-report-for-woocommerce'); ?></span></td>
				<td><input autocomplete="off" placeholder="<?php esc_html_e('E-Shop Number', 'bg-report-for-woocommerce'); ?>" name="bg_shop_number" value="<?php echo esc_html(get_option('bg_shop_number')); ?>" /></td>
            </tr>
			<tr>
				<td><span><?php esc_html_e('Domain Name: ', 'bg-report-for-woocommerce'); ?></span></td>
				<td><input autocomplete="off" placeholder="<?php esc_html_e('mysite.com', 'bg-report-for-woocommerce'); ?>" name="domain_name" value="<?php echo esc_html(get_option('domain_name')); ?>" /></td>
	        </tr> 
			<tr> 
				<td><?php //esc_html_e('Today is: ', 'report'); echo date_i18n( 'Y-m-d' ); ?>
				<span><?php esc_html_e('Creation Date: ', 'bg-report-for-woocommerce'); ?></span></td>
				<td><input autocomplete="off" placeholder="<?php esc_html_e('Creation Date', 'bg-report-for-woocommerce'); ?>" type="text" class="datepicker" name="bg_creation_date" value="<?php echo esc_html(get_option('bg_creation_date')); ?>" /></td>
			</tr>
			<tr> 
				<td><span><?php esc_html_e('Month: ', 'bg-report-for-woocommerce'); ?></span></td>
				<td>
					<?php $bg_month = esc_html(get_option('bg_month')); ?>
					<select name="bg_month"  style="width:300px;">
						<option value=""></option>
						<option value="1" <?php if ( $bg_month == "1") echo 'selected="selected"'; ?>>01</option>
						<option value="2" <?php if ( $bg_month == "2") echo 'selected="selected"'; ?>>02</option>
						<option value="3" <?php if ( $bg_month == "3") echo 'selected="selected"'; ?>>03</option>
						<option value="4" <?php if ( $bg_month == "4") echo 'selected="selected"'; ?>>04</option>
						<option value="5" <?php if ( $bg_month == "5") echo 'selected="selected"'; ?>>05</option>
						<option value="6" <?php if ( $bg_month == "6") echo 'selected="selected"'; ?>>06</option>
						<option value="7" <?php if ( $bg_month == "7") echo 'selected="selected"'; ?>>07</option>
						<option value="8" <?php if ( $bg_month == "8") echo 'selected="selected"'; ?>>08</option>
						<option value="9" <?php if ( $bg_month == "9") echo 'selected="selected"'; ?>>09</option>
						<option value="10" <?php if ( $bg_month == "10") echo 'selected="selected"'; ?>>10</option>
						<option value="11" <?php if ( $bg_month == "11") echo 'selected="selected"'; ?>>11</option>
						<option value="12" <?php if ( $bg_month == "12") echo 'selected="selected"'; ?>>12</option>
					</select>
				</td>
			</tr>
			<tr> 
				<td><span><?php esc_html_e('Year: ', 'bg-report-for-woocommerce'); ?></span></td>
				<td>
					<?php $bg_year = esc_html(get_option('bg_year')); ?>
					<select name="bg_year"  style="width:300px;">
						<option value=""></option>
						<option value="2020" <?php if ( $bg_year == "2020") echo 'selected="selected"'; ?>>2020</option>
						<option value="2021" <?php if ( $bg_year == "2021") echo 'selected="selected"'; ?>>2021</option>
						<option value="2022" <?php if ( $bg_year == "2022") echo 'selected="selected"'; ?>>2022</option>
						<option value="2023" <?php if ( $bg_year == "2023") echo 'selected="selected"'; ?>>2023</option>
						<option value="2024" <?php if ( $bg_year == "2024") echo 'selected="selected"'; ?>>2024</option>
						<option value="2025" <?php if ( $bg_year == "2025") echo 'selected="selected"'; ?>>2025</option>
						<option value="2026" <?php if ( $bg_year == "2026") echo 'selected="selected"'; ?>>2026</option>
					</select>
				</td>
			</tr>
			<tr> 
				<td>
				<span><?php esc_html_e('E-Shop Type: ', 'bg-report-for-woocommerce'); ?></span></td>
				<td><input min="1" max="2" step="1" placeholder="<?php esc_html_e('e_shop_type', 'bg-report'); ?>" type="number" min="1" name="e_shop_type" value="<?php echo esc_html(get_option('e_shop_type')); ?>" /></td>
			</tr>
			<tr>
				<td><span><?php esc_html_e('Virtual POS Name: ', 'bg-report-for-woocommerce'); ?></span></td>
				<td><input autocomplete="off" placeholder="<?php esc_html_e('Virtual POS Name', 'bg-report'); ?>" name="vpos_name" value="<?php echo esc_html(get_option('vpos_name')); ?>" /></td>
            </tr>
		</table>	
		    <div class="note-submit"><?php submit_button(); ?></div>
		</form>
		<a href="?page=bg_report&reportme=1"><?php echo esc_html_e('Generate Report', 'bg-report-for-woocommerce'); ?></a>
		<?php if(isset($_GET['reportme']) ) { ?>
		<a href="<?php echo plugin_dir_url(__FILE__) .'reports/report.xml'; ?>" download><?php echo esc_html_e('Download Report', 'bg-report-for-woocommerce'); ?></a>
		<?php } ?>
	</div>
	<?php
		function report_language_load() {
			load_plugin_textdomain('report_language_load', FALSE, basename(dirname(__FILE__)) . '/languages');
		}
		add_action('init', 'report_language_load');
		
function bg_report_date () {
				
	if (!empty(get_option('bg_month')) and !empty(get_option('bg_year'))) {

		$bg_year = esc_html(get_option('bg_year'));
		$bg_month = "0".esc_html(get_option('bg_month'));
		
		if (get_option('bg_month')>9){
			$bg_month = esc_html(get_option('bg_month'));
		}

		$mont_to = (esc_html(get_option('bg_month')));
		
		if ($mont_to>9){
			$mont_to = (esc_html(get_option('bg_month')+1));
		}
		else {
			$mont_to =(esc_html(get_option('bg_month'))+1);
		}
			
		$day = '01';
		$data_from = $bg_year."-".$bg_month."-".$day ;

		if (get_option('bg_month')==12) {
			$bg_year = ($bg_year+1);
			$mont_to = "01";
		}
		
		$data_to = $bg_year."-".($mont_to) ."-".$day;
		return $data_from."...".$data_to;
	}
	else {
		return "Select dates from - to.";
	}
}

function bg_report_complete_orders () {

	$arr_push_orders = array();
	array_unshift($arr_push_orders,"");
	unset($arr_push_orders[0]);

	$args = array(
		'limit'           => -1,
		'type'        => 'shop_order',
		'date_completed'  => bg_report_date (),
		'status'          => 'completed'
	);
	
	$query = new WC_Order_Query( $args );
	$orders = $query->get_orders();

	foreach( $orders as $order_id ) {
		$order = wc_get_order( $order_id );
	
		$arr_push_items = array();
		array_unshift($arr_push_items,"");
		unset($arr_push_items[0]);

		$order_count_arr = array();
		array_unshift($order_count_arr,"");
		unset($order_count_arr[0]);

		foreach ( $order_id->get_items() as  $item ) {
			$product_name = $item->get_name();
			$item_quantity = $item->get_quantity();
			$item_price = $order->get_item_subtotal( $item, $inc_tax, $round );
			$item_tax = $order->get_line_tax( $item );
			$get_total = $item->get_total();
			$item_vat_rate = ( ($item_tax / $item_price) * 100) / $item_quantity;
			$item_total_price_and_tax = ($item_price*$item_quantity) + $item_tax;

			$items_array = array (
				'<artenum>',
					'<art_name>'.$product_name.'</art_name>',
					'<art_quant>'.$item_quantity.'</art_quant>',
					'<art_price>'.$item_price.'</art_price>',
					'<art_vat_rate>'.$item_vat_rate.'</art_vat_rate>',
					'<art_vat>'.$item_tax.'</art_vat>',
					'<art_sum>'. number_format((float)$item_total_price_and_tax, 2, '.', '').'</art_sum>',
					'</artenum>',
				);

			$imp_items_arr = implode("",$items_array);
			array_push($arr_push_items, $imp_items_arr);
	
			$order_count++;
			array_push($order_count_arr,$order_count);
			$itm_count = count($order_count_arr);

		}
		
		$total_order_vat = $order->get_total_tax();
		$total_order_price = $order->get_subtotal();
		$ord_disc = $order->get_total_discount();

		$orders_array = array('
			<order>',
				'<rorderenum>',
					implode("", array(
					'<ord_n>'.$order->get_order_number().'</ord_n>',
					'<ord_d>'.date('Y-m-d', strtotime($order->get_date_created())).'</ord_d>',
					'<art>'
						.implode("",$arr_push_items).
						'<ord_total1>'.$itm_count.'</ord_total1>',
						'<ord_disc>'.$ord_disc.'</ord_disc>',
						'<ord_vat>'.$total_order_vat.'</ord_vat>',
						'<ord_total2>'.number_format((float)$total_order_price+$total_order_vat, 2, '.', '').'</ord_total2>',
						'<paym>'.$order->get_payment_method_title().'</paym>',
						'<pos_n>'.esc_html(get_option('vpos_name')).'</pos_n>',
						'<trans_n> '.$order->get_transaction_id().'</trans_n>',
						'<proc_id> </proc_id>',
					'</art>',
				'</rorderenum>',
				'</order>'
				)
			)
		);

		$imp_orders_arr = implode("",$orders_array);
			array_push($arr_push_orders, $imp_orders_arr);
		}

		$imp_orders = implode("",$arr_push_orders);
		return $imp_orders;
}


//Show all refunded orders 	
function bg_report_refunds () {	
	$args = array(
		'limit' => -1,
		'type' => 'shop_order',
		'date_completed' => bg_report_date (),
		'status' => 'refunded, completed'
	);
	
	$query = new WC_Order_Query( $args );//Create query with refundend orders and partial refundend orders.
	$orders = $query->get_orders();
								
	$ref_count = array();// Array with count of refundet orders.
	array_unshift($ref_count,"");
	unset($ref_count[0]);
								
	$arr_push_refunds = array();// Array refundet orders in XML. 
	array_unshift($arr_push_refunds,"");
	unset($arr_push_refunds[0]);								

	foreach( $orders as $order_id ) {
		
		$order = wc_get_order( $order_id );	//get orders by $args
		
		if( $order->get_refunds() ) { //check if is refundend orders and partial refundend order.
		
		    array_push($ref_count, $count);//Array push count of refunds
			$total_order_prices = $order->get_total_refunded();// Get refunded price
			$all_summ += $total_order_prices;// Add price in all refunded orders
			
			$r_ord =  '<r_ord> '.count($ref_count).'</r_ord>';//Get count of refunds
			$r_total =  '<r_total>'.$all_summ.'</r_total>'; // Get total price for all refunded orders.	

			foreach( $order->get_refunds() as $order_ref ) {
				
				$refund_date = $order_ref->get_date_created()->format( 'Y-m-d' );
				
				$refunds_array = array ( // Array return refunded orders in XML. 
					'<rorder>',
						'<rorderenum>',
							'<r_ord_n>'.$order->get_order_number().'</r_ord_n>',
							'<r_amount>'.$total_order_prices.'</r_amount>',
							'<r_date>'.$refund_date.'</r_date>',
							'<r_paym>'.$order->get_payment_method_title().'</r_paym>',
						'</rorderenum>',
					'</rorder>'
					);
				$imp_refunds_arr = implode("",$refunds_array); // Array implode refundet orders in XML.
				array_push($arr_push_refunds, $imp_refunds_arr);
				
			}
			
		}
	
	}
	
	$imp_orders = implode("",$arr_push_refunds);
	return $r_ord.$r_total.$imp_orders;
}

	
echo bg_report_date ();
 
$bg_report_xml = '<?xml version="1.0" encoding="WINDOWS-1251"?>
		<audit>
		<eik>'.esc_html(get_option('bg_eik')).'</eik>
		<e_shop_n>'.esc_html(get_option('bg_shop_number')).'</e_shop_n>
		<domain_name>'.esc_html(get_option('domain_name')).'</domain_name>
		<creation_date>'.esc_html(get_option('bg_creation_date')).'</creation_date>
		<mon>'.esc_html(get_option('bg_month')).'</mon>
		<god>'.esc_html(get_option('bg_year')).'</god>
		<e_shop_type>'.esc_html(get_option('e_shop_type')).'</e_shop_type>
		'.bg_report_complete_orders ().
		 bg_report_refunds ().'
		</audit>
		';
		
	if(isset($_GET['reportme'])) {
		$XMLRoot = new SimpleXMLElement($bg_report_xml);
		$path_a = plugin_dir_path(__FILE__) .'reports/report.xml';
		if ( file_exists( $path_a)) {
			unlink($path_a);
		}
		if ( !file_exists( $path_a)) {
			touch($path_a);
			file_put_contents($path_a, $XMLRoot->asXML());	
		}
	}
}